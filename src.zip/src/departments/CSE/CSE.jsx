import DepartmentLayout from "../../components/DepartmentLayout/DepartmentLayout";
import { departments } from "../../data/departments";

const CSE = () => {
  const department = departments.CSE;

  return (
    <DepartmentLayout department={department}>

      {/* Department Overview */}
      <section
        id="section-0"
        className="department-section"
      >
        <div className="section-number">01</div>

        <h2 className="section-title">
          Department Overview
        </h2>

        <div className="section-text">
          <p>
            Department content will be added here from the
            official Echelon Institute of Technology website.
          </p>
        </div>
      </section>


      {/* HOD's Message */}
      <section
        id="section-1"
        className="department-section"
      >
        <div className="section-number">02</div>

        <h2 className="section-title">
          HOD's Message
        </h2>

        <div className="section-text">
          <p>
            HOD's message will be added here.
          </p>
        </div>
      </section>


      {/* Vision & Mission */}
      <section
        id="section-2"
        className="department-section"
      >
        <div className="section-number">03</div>

        <h2 className="section-title">
          Vision and Mission
        </h2>

        <div className="section-text">
          <p>
            Vision and mission content will be added here.
          </p>
        </div>
      </section>


      {/* PEO PO PSO */}
      <section
        id="section-3"
        className="department-section"
      >
        <div className="section-number">04</div>

        <h2 className="section-title">
          PEO, PO & PSOs
        </h2>

        <div className="section-text">
          <p>
            Programme Educational Objectives, Programme
            Outcomes and Programme Specific Outcomes will
            be added here.
          </p>
        </div>
      </section>


      {/* Faculty */}
      <section
        id="section-4"
        className="department-section"
      >
        <div className="section-number">05</div>

        <h2 className="section-title">
          Faculty
        </h2>

        <div className="card-grid">

          <div className="luxury-card">
            Faculty information
          </div>

          <div className="luxury-card">
            Faculty information
          </div>

          <div className="luxury-card">
            Faculty information
          </div>

        </div>
      </section>


      {/* Laboratories */}
      <section
        id="section-5"
        className="department-section"
      >
        <div className="section-number">06</div>

        <h2 className="section-title">
          Department Laboratories
        </h2>

        <div className="card-grid">

          <div className="luxury-card">
            Laboratory information
          </div>

          <div className="luxury-card">
            Laboratory information
          </div>

          <div className="luxury-card">
            Laboratory information
          </div>

        </div>
      </section>


      {/* Newsletter */}
      <section
        id="section-6"
        className="department-section"
      >
        <div className="section-number">07</div>

        <h2 className="section-title">
          Departmental Newsletter
        </h2>

        <div className="section-text">
          <p>
            Departmental newsletter content will be added here.
          </p>
        </div>
      </section>

    </DepartmentLayout>
  );
};

export default CSE;