import DepartmentLayout from "../../components/DepartmentLayout/DepartmentLayout";
import { departments } from "../../data/departments";

const Mechanical = () => {
  const department = departments.Mechanical;

  return (
    <DepartmentLayout department={department}>

      {/* 01 — Department Overview */}
      <section
        id="section-0"
        className="department-section"
      >
        <div className="section-number">01</div>

        <h2 className="section-title">
          Department Overview
        </h2>

        <div className="section-text">
          <p>
            Department content will be added from the official
            Echelon Institute of Technology website.
          </p>
        </div>
      </section>


      {/* 02 — HOD's Message */}
      <section
        id="section-1"
        className="department-section"
      >
        <div className="section-number">02</div>

        <h2 className="section-title">
          HOD's Message
        </h2>

        <div className="section-text">
          <p>
            HOD's message will be added here.
          </p>
        </div>
      </section>


      {/* 03 — Vision and Mission */}
      <section
        id="section-2"
        className="department-section"
      >
        <div className="section-number">03</div>

        <h2 className="section-title">
          Vision and Mission
        </h2>

        <div className="section-text">
          <p>
            Vision and mission content will be added here.
          </p>
        </div>
      </section>


      {/* 04 — PEO, PO & PSOs */}
      <section
        id="section-3"
        className="department-section"
      >
        <div className="section-number">04</div>

        <h2 className="section-title">
          PEO, PO & PSOs
        </h2>

        <div className="section-text">
          <p>
            Programme Educational Objectives, Programme
            Outcomes and Programme Specific Outcomes will
            be added here.
          </p>
        </div>
      </section>


      {/* 05 — Faculty */}
      <section
        id="section-4"
        className="department-section"
      >
        <div className="section-number">05</div>

        <h2 className="section-title">
          Faculty
        </h2>

        <div className="card-grid">

          <div className="luxury-card">
            Faculty information
          </div>

          <div className="luxury-card">
            Faculty information
          </div>

          <div className="luxury-card">
            Faculty information
          </div>

        </div>
      </section>


      {/* 06 — Laboratories */}
      <section
        id="section-5"
        className="department-section"
      >
        <div className="section-number">06</div>

        <h2 className="section-title">
          Department Laboratories
        </h2>

        <div className="card-grid">

          <div className="luxury-card">
            Laboratory information
          </div>

          <div className="luxury-card">
            Laboratory information
          </div>

          <div className="luxury-card">
            Laboratory information
          </div>

        </div>
      </section>


      {/* 07 — Newsletter */}
      <section
        id="section-6"
        className="department-section"
      >
        <div className="section-number">07</div>

        <h2 className="section-title">
          Departmental Newsletter
        </h2>

        <div className="section-text">
          <p>
            Departmental newsletter content will be added here.
          </p>
        </div>
      </section>

    </DepartmentLayout>
  );
};

export default Mechanical;