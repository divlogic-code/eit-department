import React, { useEffect, useState } from "react";
import "./Home.css";

import {
  heroData,
  loanBannerData,
  centreData,
  aboutData,
  visionMissionData,
  programmeCategories,
  programmes,
  placementData,
  placementProfiles,
  recruitersData,
  affiliationsData,
  achieversData,
  sportsData,
  alumniData,
  innovationData,
  communitiesData,
  eventsData,
  podcastsData,
  shootingData,
  testimonialsData,
  celebritiesData,
  ctaData,
  homeFooterData,
  floatingActionsData,
} from "./data/home/homeContent";


// ============================================================
// SECTION HEADING
// ============================================================

function SectionHeading({ eyebrow, title, text }) {
  return (
    <div className="home-section-heading" data-gsap="heading">
      {eyebrow && <span className="eit-eyebrow">{eyebrow}</span>}

      <h2 className="eit-display">{title}</h2>

      {text && <p>{text}</p>}
    </div>
  );
}


// ============================================================
// IMAGE MARQUEE
// ============================================================

function ImageMarquee({
  items,
  className = "",
  renderItem,
}) {
  const duplicatedItems = [...items, ...items];

  return (
    <div className={`home-image-marquee ${className}`}>
      <div className="home-image-track">
        {duplicatedItems.map((item, index) =>
          renderItem(item, index)
        )}
      </div>
    </div>
  );
}


// ============================================================
// TEXT MARQUEE
// ============================================================

function TextMarquee({
  items,
  className = "",
  renderItem,
}) {
  const duplicatedItems = [...items, ...items];

  return (
    <div className={`home-marquee ${className}`}>
      <div className="home-marquee-track">
        {duplicatedItems.map((item, index) =>
          renderItem(item, index)
        )}
      </div>
    </div>
  );
}


// ============================================================
// HOME
// ============================================================

function Home() {
  const [programmeFilter, setProgrammeFilter] = useState(
    programmeCategories[0]
  );

  const filteredProgrammes = programmes.filter(
    (programme) => programme.category === programmeFilter
  );

  useEffect(() => {
    const handleScroll = () => {
      document.body.classList.toggle(
        "home-scrolled",
        window.scrollY > 80
      );
    };

    window.addEventListener("scroll", handleScroll);

    handleScroll();

    return () => {
      window.removeEventListener("scroll", handleScroll);
      document.body.classList.remove("home-scrolled");
    };
  }, []);

  return (
    <main className="home-page">

      {/* ====================================================
          FIXED VIDEO BACKGROUND
      ==================================================== */}

      <div className="home-video-background" aria-hidden="true">
        <video
          autoPlay
          muted
          loop
          playsInline
          preload="auto"
        >
          <source
            src="/videos/department-bg.mp4"
            type="video/mp4"
          />
        </video>

        <div className="home-video-overlay" />
      </div>


      {/* ====================================================
          HERO
      ==================================================== */}

      <section
        className="home-hero"
        data-gsap-section="hero"
      >
        <div
          className="home-hero-content"
          data-gsap="hero-content"
        >
          <div className="home-affiliation eit-eyebrow">
            {heroData.affiliation}
          </div>

          <h1
            className="eit-display"
            data-gsap="text-reveal"
          >
            {heroData.title}
            <br />
            <strong>{heroData.highlightedTitle}</strong>
          </h1>

          <p data-gsap="fade-up">
            {heroData.tagline}
          </p>

          <div className="home-hero-buttons">
            {heroData.buttons.map((button) => (
              <a
                key={button.label}
                href={button.href}
                className={
                  button.variant === "primary"
                    ? "home-primary-btn eit-button"
                    : "home-secondary-btn"
                }
              >
                {button.label}
              </a>
            ))}
          </div>
        </div>

        <div
          className="home-hero-stats"
          data-gsap="stagger"
        >
          {heroData.stats.map((stat) => (
            <div key={stat.label}>
              <strong>{stat.value}</strong>
              <span>{stat.label}</span>
            </div>
          ))}
        </div>
      </section>


      {/* ====================================================
          EDUCATION LOAN
      ==================================================== */}

      <section
        className="home-loan-banner"
        data-gsap-section="reveal"
      >
        <div>
          <span className="eit-eyebrow">
            {loanBannerData.eyebrow}
          </span>

          <h3 className="eit-display">
            {loanBannerData.title}
          </h3>
        </div>

        <a
          href={loanBannerData.button.href}
          className="eit-button"
        >
          {loanBannerData.button.label}
        </a>
      </section>


      {/* ====================================================
          INDUSTRY INTEGRATED CENTRE
      ==================================================== */}

      <section
        className="home-centres"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={centreData.eyebrow}
          title={centreData.title}
          text={centreData.text}
        />

        <div className="centre-marquee">
          <div className="centre-track">
            {[
              ...centreData.companies,
              ...centreData.companies,
            ].map((company, index) => (
              <div key={`${company}-${index}`}>
                {company}
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* ====================================================
          ABOUT
      ==================================================== */}

      <section
        className="home-section home-about"
        data-gsap-section="reveal"
      >
        <div className="home-two-column eit-container">

          <div className="home-about-text">
            <SectionHeading
              eyebrow={aboutData.eyebrow}
              title={aboutData.title}
            />

            {aboutData.paragraphs.map((paragraph) => (
              <p key={paragraph}>
                {paragraph}
              </p>
            ))}

            <a
              href={aboutData.button.href}
              className="home-outline-btn"
            >
              {aboutData.button.label}
            </a>
          </div>


          <div className="home-about-visual">
            <div className="home-visual-card eit-card">
              <span>{aboutData.visual.eyebrow}</span>

              <strong>{aboutData.visual.year}</strong>

              <small>{aboutData.visual.caption}</small>
            </div>
          </div>

        </div>
      </section>


      {/* ====================================================
          VISION & MISSION
      ==================================================== */}

      <section
        className="home-section home-vision"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={visionMissionData.eyebrow}
          title={visionMissionData.title}
          text={visionMissionData.text}
        />

        <div className="home-vision-grid eit-container">

          <article className="home-content-card home-vision-card eit-card">
            <span className="card-number">
              {visionMissionData.vision.number}
            </span>

            <h3>
              {visionMissionData.vision.title}
            </h3>

            <p>
              {visionMissionData.vision.text}
            </p>
          </article>


          <article className="home-content-card home-mission-card eit-card">
            <span className="card-number">
              {visionMissionData.mission.number}
            </span>

            <h3>
              {visionMissionData.mission.title}
            </h3>

            {visionMissionData.mission.items.map((mission) => (
              <div
                className="mission-item"
                key={mission.id}
              >
                <strong>{mission.id}</strong>

                <p>{mission.text}</p>
              </div>
            ))}
          </article>

        </div>
      </section>


      {/* ====================================================
          PROGRAMMES
      ==================================================== */}

      <section
        className="home-section home-programmes"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow="ACADEMICS"
          title="Programmes Designed for the Future"
          text="Choose a pathway that matches your ambition."
        />

        <div className="programme-filters">
          {programmeCategories.map((category) => (
            <button
              key={category}
              className={
                programmeFilter === category
                  ? "active"
                  : ""
              }
              onClick={() => setProgrammeFilter(category)}
            >
              {category}
            </button>
          ))}
        </div>

        <div className="programme-grid eit-container">
          {filteredProgrammes.map((programme, index) => (
            <a
              href={programme.link || "#"}
              className="programme-card eit-card"
              key={`${programme.title}-${index}`}
            >
              <span>
                {String(index + 1).padStart(2, "0")}
              </span>

              <h3>{programme.title}</h3>

              <div className="programme-card-arrow">
                →
              </div>
            </a>
          ))}
        </div>
      </section>


      {/* ====================================================
          PLACEMENTS
      ==================================================== */}

      <section
        className="home-section home-placements"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={placementData.eyebrow}
          title={placementData.title}
          text={placementData.text}
        />

        <div className="placement-stat-grid">
          {placementData.stats.map((stat) => (
            <div key={stat.label}>
              <strong>{stat.value}</strong>
              <span>{stat.label}</span>
            </div>
          ))}
        </div>

        <TextMarquee
          items={placementProfiles}
          className="placement-marquee"
          renderItem={(profile, index) => (
            <article
              className="placement-profile eit-card"
              key={`${profile.name}-${index}`}
            >
              <div className="placement-profile-image">
                {profile.image ? (
                  <img
                    src={profile.image}
                    alt={profile.name}
                  />
                ) : (
                  <span>
                    {profile.name
                      .split(" ")
                      .map((word) => word[0])
                      .slice(0, 2)
                      .join("")}
                  </span>
                )}
              </div>

              <div>
                <h3>{profile.name}</h3>

                <p>{profile.designation}</p>

                <strong>{profile.package}</strong>
              </div>
            </article>
          )}
        />

        <a
          href="/placement"
          className="home-outline-btn"
        >
          Explore Placements
        </a>
      </section>


      {/* ====================================================
          RECRUITERS
      ==================================================== */}

      <section
        className="home-section home-recruiters"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={recruitersData.eyebrow}
          title={recruitersData.title}
          text={recruitersData.text}
        />

        <TextMarquee
          items={recruitersData.recruiters}
          renderItem={(company, index) => (
            <div
              className="recruiter-logo"
              key={`${company}-${index}`}
            >
              {company}
            </div>
          )}
        />
      </section>


      {/* ====================================================
          AFFILIATIONS
      ==================================================== */}

      <section
        className="home-section home-affiliations"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={affiliationsData.eyebrow}
          title={affiliationsData.title}
          text={affiliationsData.text}
        />

        <ImageMarquee
          items={affiliationsData.items}
          renderItem={(item, index) => (
            <article
              className="home-content-card affiliation-card eit-card"
              key={`${item.title}-${index}`}
            >
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.title}
                />
              ) : (
                <div className="affiliation-symbol">
                  ✓
                </div>
              )}

              <h3>{item.title}</h3>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          ACHIEVERS
      ==================================================== */}

      <section
        className="home-section home-achievers"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={achieversData.eyebrow}
          title={achieversData.title}
          text={achieversData.text}
        />

        <ImageMarquee
          items={achieversData.achievers}
          renderItem={(achiever, index) => (
            <article
              className="home-content-card achievement-card eit-card"
              key={`${achiever.name}-${index}`}
            >
              <div className="achievement-image">
                {achiever.image ? (
                  <img
                    src={achiever.image}
                    alt={achiever.name}
                  />
                ) : (
                  <span>
                    {achiever.name.charAt(0)}
                  </span>
                )}
              </div>

              <div className="home-content-card-body">
                <h3>{achiever.name}</h3>
              </div>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          SPORTS
      ==================================================== */}

      <section
        className="home-section home-sports"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={sportsData.eyebrow}
          title={sportsData.title}
          text={sportsData.text}
        />

        <ImageMarquee
          items={sportsData.sports}
          renderItem={(sport, index) => (
            <article
              className="home-content-card image-marquee-card eit-card"
              key={`${sport.title}-${index}`}
            >
              <img
                src={sport.image}
                alt={sport.title}
              />

              <div className="home-content-card-body">
                <h3>{sport.title}</h3>
              </div>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          ALUMNI
      ==================================================== */}

      <section
        className="home-section home-alumni"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={alumniData.eyebrow}
          title={alumniData.title}
          text={alumniData.text}
        />

        <ImageMarquee
          items={alumniData.alumni}
          renderItem={(person, index) => (
            <article
              className="home-content-card alumni-card eit-card"
              key={`${person.name}-${index}`}
            >
              <div className="alumni-image">
                {person.image ? (
                  <img
                    src={person.image}
                    alt={person.name}
                  />
                ) : (
                  <span>
                    {person.name.charAt(0)}
                  </span>
                )}
              </div>

              <div className="home-content-card-body">
                <h3>{person.name}</h3>
              </div>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          INNOVATION
      ==================================================== */}

      <section
        className="home-section home-innovation"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={innovationData.eyebrow}
          title={innovationData.title}
          text={innovationData.text}
        />

        <div className="innovation-grid eit-container">

          <article className="innovation-feature eit-card">
            <img
              src={innovationData.featuredProject.image}
              alt={innovationData.featuredProject.imageAlt}
            />

            <div>
              <span>
                {innovationData.featuredProject.eyebrow}
              </span>

              <h3>
                {innovationData.featuredProject.title}
              </h3>

              <p>
                {innovationData.featuredProject.description}
              </p>
            </div>
          </article>


          {innovationData.cards.map((card) => (
            <article
              className="innovation-card eit-card"
              key={card.number}
            >
              <span>{card.number}</span>

              <h3>{card.title}</h3>

              <p>{card.description}</p>
            </article>
          ))}

        </div>
      </section>


      {/* ====================================================
          COMMUNITIES
      ==================================================== */}

      <section
        className="home-section home-communities"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={communitiesData.eyebrow}
          title={communitiesData.title}
          text={communitiesData.text}
        />

        <ImageMarquee
          items={communitiesData.communities}
          className="community-marquee"
          renderItem={(community, index) => (
            <article
              className="home-content-card community-card eit-card"
              key={`${community.title}-${index}`}
            >
              <img
                src={community.image}
                alt={community.title}
              />

              <div className="home-content-card-body">
                <span>COMMUNITY</span>

                <h3>{community.title}</h3>
              </div>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          EVENTS
      ==================================================== */}

      <section
        className="home-section home-events"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={eventsData.eyebrow}
          title={eventsData.title}
          text={eventsData.text}
        />

        <ImageMarquee
          items={eventsData.events}
          renderItem={(event, index) => (
            <article
              className="home-content-card event-card eit-card"
              key={`${event.title}-${index}`}
            >
              <div className="event-image">
                <img
                  src={event.image}
                  alt={event.title}
                />
              </div>

              <div className="home-content-card-body event-content">
                <span>ECHELON EVENT</span>

                <h3>{event.title}</h3>
              </div>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          PODCASTS
      ==================================================== */}

      <section
        className="home-section home-podcasts"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={podcastsData.eyebrow}
          title={podcastsData.title}
          text={podcastsData.text}
        />

        <div className="podcast-grid eit-container">
          {podcastsData.podcasts.map((podcast) => (
            <article
              className="podcast-card eit-card"
              key={podcast.number}
            >
              <span>{podcast.number}</span>

              <h3>{podcast.title}</h3>

              <p>{podcast.description}</p>
            </article>
          ))}
        </div>
      </section>


      {/* ====================================================
          SHOOTING @ ECHELON
      ==================================================== */}

      <section
        className="home-section home-shooting"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={shootingData.eyebrow}
          title={shootingData.title}
          text={shootingData.text}
        />

        <div className="home-image-marquee shooting-marquee">
          <div className="home-image-track">

            {[
              ...shootingData.shoots,
              ...shootingData.shoots,
            ].map((shoot, index) => (
              <article
                className="shooting-card"
                key={`${shoot.title}-${index}`}
              >

                {shoot.type === "feature" && (
                  <>
                    <img
                      src={shoot.image}
                      alt={shoot.title}
                    />

                    <div className="shooting-card-overlay" />

                    <div className="shooting-card-content">
                      <span>{shoot.platform}</span>

                      <h3>{shoot.title}</h3>

                      <p>{shoot.description}</p>
                    </div>
                  </>
                )}


                {shoot.type === "logo" && (
                  <div className="shooting-inner-card">
                    <div className="shooting-logo">
                      <img
                        src={shoot.image}
                        alt={shoot.title}
                      />
                    </div>

                    <h3>{shoot.title}</h3>

                    <p>{shoot.description}</p>
                  </div>
                )}


                {shoot.type === "text" && (
                  <div className="shooting-inner-card">
                    <span className="shooting-index">
                      {shoot.platform}
                    </span>

                    <h3>{shoot.title}</h3>

                    <p>{shoot.description}</p>
                  </div>
                )}

              </article>
            ))}

          </div>
        </div>

        <div className="shooting-footer">
          <span>{shootingData.footer.eyebrow}</span>

          <strong>{shootingData.footer.text}</strong>
        </div>
      </section>


      {/* ====================================================
          TESTIMONIALS
      ==================================================== */}

      <section
        className="home-section home-testimonials"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={testimonialsData.eyebrow}
          title={testimonialsData.title}
          text={testimonialsData.text}
        />

        <TextMarquee
          items={testimonialsData.testimonials}
          renderItem={(testimonial, index) => (
            <article
              className="testimonial-card eit-card"
              key={`${testimonial.name}-${index}`}
            >
              <div className="testimonial-mark">
                “
              </div>

              <p>{testimonial.text}</p>

              <strong>{testimonial.name}</strong>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          CELEBRITIES
      ==================================================== */}

      <section
        className="home-section home-celebrities"
        data-gsap-section="reveal"
      >
        <SectionHeading
          eyebrow={celebritiesData.eyebrow}
          title={celebritiesData.title}
          text={celebritiesData.text}
        />

        <ImageMarquee
          items={celebritiesData.celebrities}
          renderItem={(celebrity, index) => (
            <article
              className="celebrity-card eit-card"
              key={`${celebrity.name}-${index}`}
            >
              <div className="celebrity-image">
                {celebrity.image ? (
                  <img
                    src={celebrity.image}
                    alt={celebrity.name}
                  />
                ) : (
                  <span>
                    {celebrity.name.charAt(0)}
                  </span>
                )}
              </div>

              <h3>{celebrity.name}</h3>
            </article>
          )}
        />
      </section>


      {/* ====================================================
          CTA
      ==================================================== */}

      <section
        className="home-cta"
        data-gsap-section="reveal"
      >
        <div className="home-cta-content">
          <span className="eit-eyebrow">
            {ctaData.eyebrow}
          </span>

          <h2 className="eit-display">
            {ctaData.title}
            <br />
            {ctaData.highlightedTitle}
          </h2>

          <p>{ctaData.tagline}</p>

          <div className="home-cta-buttons">
            {ctaData.buttons.map((button) => (
              <a
                key={button.label}
                href={button.href}
                className={
                  button.variant === "primary"
                    ? "home-primary-btn eit-button"
                    : "home-secondary-btn"
                }
              >
                {button.label}
              </a>
            ))}
          </div>
        </div>
      </section>


      {/* ====================================================
          FOOTER
      ==================================================== */}

      <footer className="home-footer">
        <div className="home-footer-grid">

          <div className="home-footer-brand">
            <h2 className="eit-display">
              {homeFooterData.brand.title}
            </h2>

            <p>{homeFooterData.brand.institute}</p>
            <p>{homeFooterData.brand.location}</p>
            <p>{homeFooterData.brand.affiliation}</p>
          </div>


          {homeFooterData.columns.map((column) => (
            <div
              className="home-footer-column"
              key={column.title}
            >
              <h3>{column.title}</h3>

              {column.links.map((link) => (
                <a
                  key={link.label}
                  href={link.href}
                >
                  {link.label}
                </a>
              ))}
            </div>
          ))}

        </div>

        <div className="home-footer-bottom">
          <span>
            © {new Date().getFullYear()} Echelon Institute of Technology
          </span>

          <span>
            All Rights Reserved
          </span>
        </div>
      </footer>


      {/* ====================================================
          FLOATING ACTIONS
      ==================================================== */}

      <div
        className="home-floating-actions"
        data-gsap="floating-actions"
      >
        {floatingActionsData.map((action) => (
          <a
            key={action.label}
            href={action.href}
          >
            {action.label}
          </a>
        ))}
      </div>

    </main>
  );
}

export default Home;