import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./Home";

// Common layout components
import Navbar from "./components/Navbar/Navbar";

// About Us
import AboutEchelon from "./AboutUs/AboutEchelon";
import Affiliations from "./AboutUs/Affiliations";
import BoardOfGovernors from "./AboutUs/BoardOfGovernors";
import Chairman from "./AboutUs/Chairman";
import Director from "./AboutUs/Director";
import ISO from "./AboutUs/ISO";
import OrganisationalStructure from "./AboutUs/OrganisationalStructure";
import Philosophy from "./AboutUs/Philosophy";
import VisionMission from "./AboutUs/VisionMission";

// Academics
import AcademicCalendar from "./Academics/AcademicCalendar";
import NBANAAC from "./Academics/NBANAAC";
import ProgramOffered from "./Academics/ProgramOffered";
import SchemeCalendar from "./Academics/SchemeCalendar";

// Admissions
import AdmissionBrochure from "./Admissions/AdmissionBrochure";
import AdmissionProcedure from "./Admissions/AdmissionProcedure";
import AntiRagging from "./Admissions/AntiRagging";
import DocumentChecklist from "./Admissions/DocumentChecklist";
import EligibilityCriteria from "./Admissions/EligibilityCriteria";
import FeeReimbursement from "./Admissions/FeeReimbursement";
import FeeStructure from "./Admissions/FeeStructure";
import IPUCET from "./Admissions/IPUCET";
import OnlineApplication from "./Admissions/OnlineApplication";
import RefundPolicy from "./Admissions/RefundPolicy";
import Scholarship from "./Admissions/Scholarship";
import WhyEchelon from "./Admissions/WhyEchelon";

// Career
import Career from "./Career/Career";

// Contact
import Contact from "./Contact/Contact";

// Departments
import CSE from "./departments/CSE/CSE";
import ECE from "./departments/ECE/ECE";
import Mechanical from "./departments/Mechanical/Mechanical";
import Civil from "./departments/Civil/Civil";
import Humanities from "./departments/Humanities/Humanities";
import Management from "./departments/Management/Management";
import ComputerApplications from "./departments/ComputerApplications/ComputerApplications";

// Research
import BookChapters from "./Research/BookChapters";
import Conferences from "./Research/Conferences";
import EDC from "./Research/EDC";
import FDPs from "./Research/FDPs";
import IIC from "./Research/IIC";
import IPR from "./Research/IPR";
import JournalPapers from "./Research/JournalPapers";
import MOUs from "./Research/MOUs";
import Patents from "./Research/Patents";
import RDCommittee from "./Research/RDCommittee";

// Placement
import PlacementOverview from "./Placement/Overview";
import HeadMessage from "./Placement/HeadMessage";
import HighestPerformers from "./Placement/HighestPerformers";
import HRConclave from "./Placement/HRConclave";
import IndustrialVisits from "./Placement/IndustrialVisits";
import IndustryExpertLectures from "./Placement/IndustryExpertLectures";
import MegaJobFair from "./Placement/MegaJobFair";
import PlacementMOUs from "./Placement/MOUs";
import PlacementBrochure from "./Placement/PlacementBrochure";
import PlacementGallery from "./Placement/PlacementGallery";
import PlacementPolicy from "./Placement/PlacementPolicy";
import PlacementProcess from "./Placement/PlacementProcess";
import Recruiters from "./Placement/Recruiters";
import RecruitersSpeak from "./Placement/RecruitersSpeak";
import SkillDevelopment from "./Placement/SkillDevelopment";
import StudentsSpeak from "./Placement/StudentsSpeak";
import UpcomingEvents from "./Placement/UpcomingEvents";
import PlacementVisionMission from "./Placement/VisionMission";

// Other main pages
import IQAC from "./IQAC/IQAC";
import Notices from "./Notices/Notices";

// ICSCCI 2027
import ICSCCIAbout from "./ICSCCI2027/About";
import CallForPapers from "./ICSCCI2027/CallForPapers";
import Committee from "./ICSCCI2027/Committee";
import ImportantDates from "./ICSCCI2027/ImportantDates";
import PaperSubmission from "./ICSCCI2027/PaperSubmission";
import Registration from "./ICSCCI2027/Registration";
import Speakers from "./ICSCCI2027/Speakers";

// Global CSS
import "./styles/CSS.css";


function App() {
  return (
    <BrowserRouter>
      <Navbar />

      <Routes>

        {/* =========================
            HOME
        ========================= */}
        <Route path="/" element={<Home />} />


        {/* =========================
            ABOUT US
        ========================= */}
        <Route
          path="/about-eit"
          element={<AboutEchelon />}
        />

        <Route
          path="/affiliations"
          element={<Affiliations />}
        />

        <Route
          path="/board-of-governors"
          element={<BoardOfGovernors />}
        />

        <Route
          path="/chairman"
          element={<Chairman />}
        />

        <Route
          path="/director"
          element={<Director />}
        />

        <Route
          path="/iso"
          element={<ISO />}
        />

        <Route
          path="/organisational-structure"
          element={<OrganisationalStructure />}
        />

        <Route
          path="/philosophy"
          element={<Philosophy />}
        />

        <Route
          path="/vision-mission"
          element={<VisionMission />}
        />


        {/* =========================
            ACADEMICS
        ========================= */}
        <Route
          path="/academic-calendar"
          element={<AcademicCalendar />}
        />

        <Route
          path="/nba-naac"
          element={<NBANAAC />}
        />

        <Route
          path="/program-offered"
          element={<ProgramOffered />}
        />

        <Route
          path="/scheme-calendar"
          element={<SchemeCalendar />}
        />


        {/* =========================
            ADMISSIONS
        ========================= */}
        <Route
          path="/admission-brochure"
          element={<AdmissionBrochure />}
        />

        <Route
          path="/admission-procedure"
          element={<AdmissionProcedure />}
        />

        <Route
          path="/anti-ragging"
          element={<AntiRagging />}
        />

        <Route
          path="/document-checklist"
          element={<DocumentChecklist />}
        />

        <Route
          path="/eligibility-criteria"
          element={<EligibilityCriteria />}
        />

        <Route
          path="/fee-reimbursement"
          element={<FeeReimbursement />}
        />

        <Route
          path="/fee-structure"
          element={<FeeStructure />}
        />

        <Route
          path="/ipu-cet"
          element={<IPUCET />}
        />

        <Route
          path="/online-application"
          element={<OnlineApplication />}
        />

        <Route
          path="/refund-policy"
          element={<RefundPolicy />}
        />

        <Route
          path="/scholarship"
          element={<Scholarship />}
        />

        <Route
          path="/why-echelon"
          element={<WhyEchelon />}
        />


        {/* =========================
            DEPARTMENTS
        ========================= */}
        <Route
          path="/cse"
          element={<CSE />}
        />

        <Route
          path="/ece"
          element={<ECE />}
        />

        <Route
          path="/mechanical"
          element={<Mechanical />}
        />

        <Route
          path="/civil"
          element={<Civil />}
        />

        <Route
          path="/humanities"
          element={<Humanities />}
        />

        <Route
          path="/management"
          element={<Management />}
        />

        <Route
          path="/computer-applications"
          element={<ComputerApplications />}
        />


        {/* =========================
            PLACEMENT
        ========================= */}
        <Route
          path="/placement"
          element={<PlacementOverview />}
        />

        <Route
          path="/placement/overview"
          element={<PlacementOverview />}
        />

        <Route
          path="/placement/head-message"
          element={<HeadMessage />}
        />

        <Route
          path="/placement/highest-performers"
          element={<HighestPerformers />}
        />

        <Route
          path="/placement/hr-conclave"
          element={<HRConclave />}
        />

        <Route
          path="/placement/industrial-visits"
          element={<IndustrialVisits />}
        />

        <Route
          path="/placement/industry-expert-lectures"
          element={<IndustryExpertLectures />}
        />

        <Route
          path="/placement/mega-job-fair"
          element={<MegaJobFair />}
        />

        <Route
          path="/placement/mous"
          element={<PlacementMOUs />}
        />

        <Route
          path="/placement/brochure"
          element={<PlacementBrochure />}
        />

        <Route
          path="/placement/gallery"
          element={<PlacementGallery />}
        />

        <Route
          path="/placement/policy"
          element={<PlacementPolicy />}
        />

        <Route
          path="/placement/process"
          element={<PlacementProcess />}
        />

        <Route
          path="/placement/recruiters"
          element={<Recruiters />}
        />

        <Route
          path="/placement/recruiters-speak"
          element={<RecruitersSpeak />}
        />

        <Route
          path="/placement/skill-development"
          element={<SkillDevelopment />}
        />

        <Route
          path="/placement/students-speak"
          element={<StudentsSpeak />}
        />

        <Route
          path="/placement/upcoming-events"
          element={<UpcomingEvents />}
        />

        <Route
          path="/placement/vision-mission"
          element={<PlacementVisionMission />}
        />


        {/* =========================
            RESEARCH
        ========================= */}
        <Route
          path="/research/book-chapters"
          element={<BookChapters />}
        />

        <Route
          path="/research/conferences"
          element={<Conferences />}
        />

        <Route
          path="/research/edc"
          element={<EDC />}
        />

        <Route
          path="/research/fdps"
          element={<FDPs />}
        />

        <Route
          path="/research/iic"
          element={<IIC />}
        />

        <Route
          path="/research/ipr"
          element={<IPR />}
        />

        <Route
          path="/research/journal-papers"
          element={<JournalPapers />}
        />

        <Route
          path="/research/mous"
          element={<MOUs />}
        />

        <Route
          path="/research/patents"
          element={<Patents />}
        />

        <Route
          path="/research/rd-committee"
          element={<RDCommittee />}
        />


        {/* =========================
            CAREER / CONTACT / IQAC
        ========================= */}
        <Route
          path="/career"
          element={<Career />}
        />

        <Route
          path="/contact"
          element={<Contact />}
        />

        <Route
          path="/iqac"
          element={<IQAC />}
        />

        <Route
          path="/notices"
          element={<Notices />}
        />


        {/* =========================
            ICSCCI 2027
        ========================= */}
        <Route
          path="/icscci-2027"
          element={<ICSCCIAbout />}
        />

        <Route
          path="/icscci-2027/about"
          element={<ICSCCIAbout />}
        />

        <Route
          path="/icscci-2027/call-for-papers"
          element={<CallForPapers />}
        />

        <Route
          path="/icscci-2027/committee"
          element={<Committee />}
        />

        <Route
          path="/icscci-2027/important-dates"
          element={<ImportantDates />}
        />

        <Route
          path="/icscci-2027/paper-submission"
          element={<PaperSubmission />}
        />

        <Route
          path="/icscci-2027/registration"
          element={<Registration />}
        />

        <Route
          path="/icscci-2027/speakers"
          element={<Speakers />}
        />


        {/* =========================
            FALLBACK
        ========================= */}
        <Route
          path="*"
          element={<Home />}
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;